<?php 
require('top.php');
?>
<html lang="en">
 <section class="htc__contact__area ptb--100 bg__white">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="about-section">
        <div class="inner-container">
           <center><h1>About Us</h1><center>
		   
		   <br>
		   <br>
           <center> <p class="text">
              We are  creators of this website.<br>
This project is currently under progress.<br>The members of our group are Vinayak, Purvisha, Omkar<br> We are making an attempt to provide a platform for the students of VCET to showcase their skills.<br> We the students of CSE have made an attempt to create a solution for the student interaction
            </p><center>
            <div class="skills">
                <span>Web Design</span>
                <span>Photoshop & Illustrator</span>
                <span>Coding</span>
            </div>
        </div>
    </div>
</body>
</html>


<?php require('footer.php')?>    