
<?php require('top.php')?>
<html>
 <section class="htc__contact__area ptb--100 bg__white">
<body>
	<h1><center><b>
	Introduction<b></h1>
	
	</center><br><br>
<h2><center>By joining the Forum, you’ll have access to our highly-acclaimed peer-to-peer mentoring<br> programme and an exclusive series of inspirational events which will energise you and help you build a mindset of confidence and determination.</h2><center>
	<img src = "images/banner/corporate.png" width="400" height="500">
<h2><center><b>“We have an incredible amount of entrepreneurial talent<br> across the region and being part of a supportive <br>community, where people want to help each other to succeed,<br> is invaluable.”<br><br><center><b>
<center>Sara Davies MBE, Crafter's Companion<center></h2>

		
</body>
</html>

<?php require('footer.php')?>