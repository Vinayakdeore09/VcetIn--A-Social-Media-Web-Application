<?php require('top.php')?>


<html>
	<title> DCODRZ</title>
	<body>
	
	<center><h1> NO LATEST ANNOUNCEMENT!!</H1><center>
	<br>
	<center><img src = "images/banner/notfound.png"><center>
	</body>

</html>


<?php require('footer.php')?>